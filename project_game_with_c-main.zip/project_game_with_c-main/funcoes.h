#define MAX_PLAYERS 100

char** primeiro_periodo();
char** professores();
int soma(int);
int tamanho_matriz_ponteiros(char** lista);
int tamanho_matriz_normal(char* **lista);